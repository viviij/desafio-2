import axios from 'axios'
import { useState } from 'react'

const baseURL = 'https://amazon-api.sellead.com/country'
export function paises() {
  const [teste, setTest] = useState('')
  axios
    .get(baseURL)
    .then(response => {
      setTest(response.data.name)
    })
    .catch(error => console.log(error))
  return teste
}
