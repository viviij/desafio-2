import axios from 'axios'

const cidades = axios.create({
  baseURL: 'https://amazon-api.sellead.com/city'
})
