import axios from 'axios'

export const cidades = axios.create({
  baseURL: 'https://amazon-api.sellead.com/city'
})
