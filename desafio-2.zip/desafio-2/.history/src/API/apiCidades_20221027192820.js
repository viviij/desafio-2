import axios from 'axios'

export default cidades = axios.create({
  baseURL: 'https://amazon-api.sellead.com/city'
})
