import axios from 'axios'
import { useState } from 'react'

const url = 'https://amazon-api.sellead.com/country'
export function paises() {
  const [options, setOptions] = useState([''])

  useEffect(() => {
    const getData = async () => {
      const arr = []
      await axios.get(url).then(res => {
        let result = res.data
        result.map(user => {
          return arr.push({ value: user.id, label: user.name })
        })
        setOptions(arr)
      })
    }
    getData()
  }, [])

  return options
}
