import axios from 'axios'

const baseURL = 'https://amazon-api.sellead.com/country'
export function paises() {
  axios
    .get(baseURL)
    .then(response => {
      return response
    })
    .catch(error => console.log(error))
}
