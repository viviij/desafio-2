import Axios from 'axios'
import { useState } from 'react'

const baseURL = 'https://amazon-api.sellead.com/country'
export function paises() {
  const [teste, setTest] = useState('')
  Axios.get(baseURL)
    .then(response => {
      setTest(response.data.name)
    })
    .catch(error => console.log(error))
}
