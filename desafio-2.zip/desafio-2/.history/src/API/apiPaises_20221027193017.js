import axios from 'axios'

const paises = axios.create({
  baseURL: 'https://amazon-api.sellead.com/country'
})

export default paises
