import { Cadastro } from "../pages/Cadastro";


export function Registro({name, phone, cpf, email, city, country}) {
  return(
    <div>
      <p>Name: {name}</p>
      <p>Phone: {phone}</p>
      <p>CPF: {cpf}</p>
      <p>Email: {email}</p>
      <p>City: {city.label}</p>

    </div>
  )
} 