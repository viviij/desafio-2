export function Registro() {
  return(
    <h1>pato</h1>
  )
} 