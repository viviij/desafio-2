import { Cadastro } from "../pages/Cadastro";


export function Registro(pato) {
  return(
    <h1>pato</h1>
  )
} 