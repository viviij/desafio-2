import { Cadastro } from './pages/Cadastro'

export function App() {
  return (
    < Cadastro/>
  )
}

