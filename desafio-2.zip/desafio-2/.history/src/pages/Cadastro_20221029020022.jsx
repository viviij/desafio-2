import styles from './Cadastro.module.css'

import Select from 'react-select'

import { useEffect, useState } from "react";
import axios from "axios";

// O desafio é consideravelmente dificil pela minha falta de conhecimento, mas não impossivel
// Devo terminar em aproximadamente 2 dias
// O dificil seria puxar a API para fazer uma lista dos paises e
// Apesar de n ter sido pedido parece essencial o cliente conseguir ver oq registrou
// O valor posso salvar em um useState, acho q isso n vai ser um problema
// As etapas seriam então

//1 Armazenar todo conteudo e logica dentro de "Cadastro.jsx"
//2 Colocar os elementos essencias do site, sem funcionar, apenas criar a estrutura basica
//3 Puxar as cidades e países da API para a lista, usando um map?
//4 Salvar todos os valores dentro de uma variavel 
//5 Fazer a estilização basica via um module.css
//6 Criar o espaço para o lugar onde será armazenados os valores registrados
//7 Mostrar os resultados salvos do novo registro criado
//7.1 Talvez não seja interessante deixar essa parte dentro de "Cadastro.jsx"
//    Só vale a pena manter dentro de Cadastro, caso eu
// O SELECT N ESTA RETORNANDO A LISTA DA API - problema resolvido
// O USESTATE DO COUNTRY ESTA SENDO USADO PARA ARMAZENAR O VALOR DO SELECT - problema resolvido
// N ESTA SENDO POSSIVEL SELECIONAR MAIS DE UM ITEM DA CHAMADA DE API - Problema resolvido

const url = "https://amazon-api.sellead.com/country";




export function Cadastro() {
  const [country, setCountry] = useState([]); 
  const [valueCountry, setValueCountry] = useState([]); 

  useEffect(() => {
    const listCountry = async () => {
      const response = await axios.get(url);
      const users = response.data;
      setCountry(users.map((user) => ({ value: user.code, label: user.name })))
    };

    listCountry();
  }, []);


  // console.log(edferferf)

  const opcaoes = [
    { value: 'ocean', label: 'Ocean', color: '#00B8D9', isFixed: true },
    { value: 'blue', label: 'Blue', color: '#0052CC', isDisabled: true },
    { value: 'purple', label: 'Purple', color: '#5243AA' },
    { value: 'red', label: 'Red', color: '#FF5630', isFixed: true },
    { value: 'orange', label: 'Orange', color: '#FF8B00' },
    { value: 'yellow', label: 'Yellow', color: '#FFC400' },
    { value: 'green', label: 'Green', color: '#36B37E' },
    { value: 'forest', label: 'Forest', color: '#00875A' },
    { value: 'slate', label: 'Slate', color: '#253858' },
    { value: 'silver', label: 'Silver', color: '#666666' },
  ];
  

  return(
    <main className={styles.main}>
      <div className={styles.cadastroInformacoes}>
        
        <div className="form">
          <p>Nome</p>
          <input type='text' name='nome' placeholder='Enter your email' />
                      
          <p>Email</p>
          <input type="text" name='email' placeholder='*******'
          checked />

          <p>Telefone</p>
          <input type="text" name='telefone' placeholder='55 11 12345-6789'
          checked />
          <p>CPF</p>
          <input type="text" name='email' placeholder='123.456.789-00'
          checked />

        </div>
      
      </div>

      <div className={styles.cadastroDestino}>
        <p>cidades</p>
        <Select
      
          isMulti
          name="colors"
          options={opcaoes}
          className="basic-multi-select"
          classNamePrefix="select"
          
        />
        <p>país</p>
        <Select
          isMulti
          name="country"
          options={country}
          value={valueCountry}
          onChange={setValueCountry}
          className="basic-multi-select"
          classNamePrefix="select"
          
        />
      </div>
    </main>
  )
}