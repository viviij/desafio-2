export function Cadastro() {
  return(
    <h1>Deesafio 2</h1>
  )
}