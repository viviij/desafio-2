import styles from './Cadastro.module.css'

export function Cadastro() {
  return(
    <main className={styles.main}>
      <div>feijao</div>
      <div><h1>pato</h1></div>

    </main>
  )
}