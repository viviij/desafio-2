import styles from './Cadastro.module.css'

import Select from 'react-select'

import { useEffect, useState } from "react";
import axios from "axios";

const url = "https://amazon-api.sellead.com/country";

// N ESTA SENDO POSSIVEL SELECIONAR MAIS DE UM ITEM DA CHAMADA DE API
export function Cadastro() {
  const [country, setCountry] = useState(['']); 
  const [valueCountry, setValueCountry] = useState(['']); 

  useEffect(() => {
    const listCountry = async () => {
      const response = await axios.get(url);
      const users = response.data;
      setCountry(users.map((user) => ({ value: user.id, label: user.name })));
    };

    listCountry();
  }, []);
  
  function testet () {
    console.log(country)
  }

  const opcaoes = [
    { value: 'ocean', label: 'Ocean', color: '#00B8D9', isFixed: true },
    { value: 'blue', label: 'Blue', color: '#0052CC', isDisabled: true },
    { value: 'purple', label: 'Purple', color: '#5243AA' },
    { value: 'red', label: 'Red', color: '#FF5630', isFixed: true },
    { value: 'orange', label: 'Orange', color: '#FF8B00' },
    { value: 'yellow', label: 'Yellow', color: '#FFC400' },
    { value: 'green', label: 'Green', color: '#36B37E' },
    { value: 'forest', label: 'Forest', color: '#00875A' },
    { value: 'slate', label: 'Slate', color: '#253858' },
    { value: 'silver', label: 'Silver', color: '#666666' },
  ];
  

  console.log(country)
  console.log(valueCountry)
  return(
    <main className={styles.main}>
      <div className={styles.cadastroInformacoes}>
        
        <div className="form">
          <p>Nome</p>
          <input type='text' name='nome' placeholder='Enter your email' />
                      
          <p>Email</p>
          <input type="text" name='email' placeholder='*******'
          checked />

          <p>Telefone</p>
          <input type="text" name='telefone' placeholder='55 11 12345-6789'
          checked />
          <p>CPF</p>
          <input type="text" name='email' placeholder='123.456.789-00'
          checked />

        </div>
      
      </div>

      <div className={styles.cadastroDestino}>
        <button onClick={testet}></button>
        <p>cidades</p>
        <Select
      
          isMulti
          name="colors"
          options={opcaoes}
          className="basic-multi-select"
          classNamePrefix="select"
        />
        <p>país</p>
        <Select
          isMulti
          name="country"
          options={country}
          value={country}
          className="countryList"
        />
      </div>

    </main>
  )
}