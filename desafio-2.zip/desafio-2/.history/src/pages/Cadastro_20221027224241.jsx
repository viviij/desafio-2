import styles from './Cadastro.module.css'

import Select from 'react-select'

import { useEffect, useState } from "react";
import axios from "axios";

import apiCidades from '../API/apiCidades'
import { paises } from '../API/apiPaises'
const url = "https://amazon-api.sellead.com/city";
export function Cadastro() {
  const [options, setOptions] = useState([""]);

  function pato () {
    useEffect(() => {
      const getData = async () => {
        const arr = [];
        await axios.get(url).then((res) => {
          let result = res.data.items;
          result.map((user) => {
            return arr.push({value: user.login, label: user.login});
          });
          setOptions(arr)
        });
      };
      getData();
    }, []);

  }
  

  const opcaoes = [
    { value: 'ocean', label: 'Ocean', color: '#00B8D9', isFixed: true },
    { value: 'blue', label: 'Blue', color: '#0052CC', isDisabled: true },
    { value: 'purple', label: 'Purple', color: '#5243AA' },
    { value: 'red', label: 'Red', color: '#FF5630', isFixed: true },
    { value: 'orange', label: 'Orange', color: '#FF8B00' },
    { value: 'yellow', label: 'Yellow', color: '#FFC400' },
    { value: 'green', label: 'Green', color: '#36B37E' },
    { value: 'forest', label: 'Forest', color: '#00875A' },
    { value: 'slate', label: 'Slate', color: '#253858' },
    { value: 'silver', label: 'Silver', color: '#666666' },
  ];
  
  return(
    <main className={styles.main}>
      <div className={styles.cadastroInformacoes}>
        
        <div className="form">
          <p>Nome</p>
          <input type='text' name='nome' placeholder='Enter your email' />
                      
          <p>Email</p>
          <input type="text" name='email' placeholder='*******'
          checked />

          <p>Telefone</p>
          <input type="text" name='telefone' placeholder='55 11 12345-6789'
          checked />
          <p>CPF</p>
          <input type="text" name='email' placeholder='123.456.789-00'
          checked />

        </div>
      
      </div>

      <div className={styles.cadastroDestino}>
        <button onClick={options}></button>
        <p>Telefone</p>
        <Select
      
          isMulti
          name="colors"
          options={opcaoes}
          className="basic-multi-select"
          classNamePrefix="select"
        />
        <p>CPF</p>
        <Select

          isMulti
          name="colors"
          options={options}
          className="basic-multi-select"
          classNamePrefix="select"
        />
      </div>

    </main>
  )
}