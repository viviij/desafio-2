import styles from './Cadastro.module.css'

import axios from 'axios'
import Select from 'react-select';

export function Cadastro() {

  function newCommentChange() {
    // axiosR.get('https://amazon-api.sellead.com/country')
    axios.get('https://amazon-api.sellead.com/country')
    .then(function (response) {
      // manipula o sucesso da requisição
      console.log(response);
    })
  }
  
  return(
    <main className={styles.main}>
      <div className={styles.cadastroInformacoes}>
        
        <div className="form">
          <p>Nome</p>
          <input type='text' name='nome' placeholder='Enter your email' />
                      
          <p>Email</p>
          <input type="text" name='email' placeholder='*******'
          checked />

          <p>Telefone</p>
          <input type="text" name='telefone' placeholder='55 11 12345-6789'
          checked />
          <p>CPF</p>
          <input type="text" name='email' placeholder='123.456.789-00'
          checked />

        </div>
      
      </div>

      <div className={styles.cadastroDestino}>
        <p>Telefone</p>
        <Select
      
          isMulti
          name="colors"
          options={newCommentChange}
          className="basic-multi-select"
          classNamePrefix="select"
        />
        <p>CPF</p>
        <Select

          isMulti
          name="colors"
          options={newCommentChange}
          className="basic-multi-select"
          classNamePrefix="select"
        />
      </div>

    </main>
  )
}