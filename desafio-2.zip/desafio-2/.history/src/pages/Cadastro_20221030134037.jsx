import styles from './Cadastro.module.css'

import Select from 'react-select'

import { useEffect, useState } from "react";
import axios from "axios";
import { Registro } from '../components/Registro';
import { cpfValidation } from '../function/cpfValidation';
// O desafio é consideravelmente dificil pela minha falta de conhecimento, mas não impossivel
// O dificil seria puxar a API para fazer uma lista dos paises e
// Apesar de n ter sido pedido parece essencial o cliente conseguir ver oq registrou
// O valor posso salvar em um useState, acho q isso n vai ser um problema
// As etapas seriam então

//1 Armazenar todo conteudo e logica dentro de "Cadastro.jsx" - Feito
//2 Colocar os elementos essencias do site, sem funcionar, apenas criar a estrutura basica - Feito
//3 Puxar as cidades e países da API para a lista, usando um map? - Feito
//4 Salvar todos os valores dentro de uma variavel - Feito
//5 Fazer a estilização basica via um module.css - Em andamento
//6 Criar o espaço para o lugar onde será armazenados os valores registrados  - Feito
//7 Mostrar os resultados salvos do novo registro criado - Feito
//7.1 Talvez não seja interessante deixar essa parte dentro de "Cadastro.jsx"
//    Só vale a pena manter dentro de Cadastro, caso eu so mostre o ultimo valor cadastrado 
//    Se n for o caso, compensa mais criar um novo componente, já que varios registros 
//    Usariam a mesma estrutura, mas armazenariam conteudo diferentes 
//8 Não é o foco do desafio eu acredito, mas talvez seja interessante fazer uma verificação cpf
//8.1 Talvez seja interessante tambem fazer auto formatação do telefone e cpf


//Erros(N ESQUECE DE RESOLVER)
// O SELECT N ESTA RETORNANDO A LISTA DA API - problema resolvido
// O USESTATE DO COUNTRY ESTA SENDO USADO PARA ARMAZENAR O VALOR DO SELECT - problema resolvido
// N ESTA SENDO POSSIVEL SELECIONAR MAIS DE UM ITEM DA CHAMADA DE API - Problema resolvido
// VALIDAÇÃO DO CPF FEITA, MAS N TA FAZENDO NADA NO CODIGO, PRECISO DAR UMA FUNÇÃO PRA ELA

export function Cadastro() {
  //----------------API----------------------//
  //URL DAS API
  const urlAPICountry = "https://amazon-api.sellead.com/country";
  const urlAPICity = "https://amazon-api.sellead.com/city";
  
  //Armazenar o valor da lista dos países e cidades puxados da API 
  const [country, setCountry] = useState([]); 
  const [valueCountry, setValueCountry] = useState([]); 
  
  const [city, setCity] = useState([]); 
  const [valueCity, setValueCity] = useState([]); 

  //Funcões reponsaveis pela criação das informações do Select usando a API da amazon
  useEffect(() => {
    const listCountry = async () => {
      const response = await axios.get(urlAPICountry);
      const country = response.data;
      setCountry(country.map((country) => ({ value: country.code, label: country.name })))
    };

    listCountry();
  }, []);

  useEffect(() => {
    const listCity = async () => {
      const response = await axios.get(urlAPICity);
      const city = response.data;
      setCity(city.map((city) => ({ value: city.id, label: city.name })))
    };

    listCity();
  }, []);
  //------------------------API/-----------------------//

  //------------BOTÃO ENVIAR E FORMULARIOS-------------//
  //Armazenar os valores preenchidos 
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [telephone, setTelephone] = useState('')
  const [cpf, setCpf] = useState('')
  
  
  const [allRegistryValue, setAllRegistryValue] = useState([''])

  //Funções responsaveis por salvar os valores preenchidos na variavel respectiva 
  function SaveRegisteredName() {
    setName(event.target.value)
  }

  function SaveRegisteredEmail() {
    setEmail(event.target.value)
  }

  function SaveRegisteredTelephone() {
    setTelephone(event.target.value)
  }

  function SaveRegisteredCpf() {
    setCpf(event.target.value)
  }

  //Verificar se existe algum campo obrigatório não preenchido e botão de submit
  const cityList = []
  const countryList = []

  const [countryStringValue, setCountryStringValue] = useState('')
  const [cityStringValue, setCityStringValue] = useState('')
  function Submit() {//IF RESPONSAVEL POR REALIZAR A FUNÇÃO DE SUBMIT, CASO NENHUM VALOR SEJA VAZIO
                    //Em resumo, está guardando os valores registrados dentro de variaveis, para mostrar em tela
    if(name != '' && email != '' && telephone != '' && cpf != '' && valueCountry != '' && valueCity != '') {
      console.log(cpfValidation(51972906844))
      let warehouseOfRegistrationValues = {
        name: name,
        email: email,
        telephone: telephone,
        cpf: cpf,
      }
      setAllRegistryValue(warehouseOfRegistrationValues)

      valueCity?.map(element => cityList.push(element.label))
      valueCountry?.map(element => countryList.push(element.label))
      
      const listCityConvertedToString = cityList.join(" | ")
      const listCountriesConvertedToString = countryList.join(" | ")

      setCityStringValue(listCityConvertedToString)
      setCountryStringValue(listCountriesConvertedToString)

    }else{//ELSE RESPONSAVEL POR DAR FOCO NO INPUT NÃO PREENCHIDO
      alert('Preencha todos os campos obrigatórios')
      if(name == ''){   
        const getNameById = document.getElementById("name")
        getNameById.focus();

      }else if(email == ''){
        const getEmailById = document.getElementById("email")
        getEmailById.focus();

      }else if(telephone == ''){
        const getTelephoneById = document.getElementById("telephone")
        getTelephoneById.focus();

      }else if(cpf == ''){
        const getCpfById = document.getElementById("cpf")
        getCpfById.focus();

      }else if(valueCountry == ''){
        const getCountryById = document.getElementById("countryNameId")
        getCountryById.focus()

      }else if(valueCity == ''){
        const getCityById = document.getElementById("cityNameId")
        getCityById.focus();

      }

    }

  }
  return(
    <main className={styles.main}>
      <div className={styles.cadastroInformacoes}>
        
        <div className="form">
          <p>*Nome</p>
          <input type='text' className='pato' name='nome' id='name' onChange={SaveRegisteredName} placeholder='Enter your email' />
                      
          <p>*Email</p>
          <input type="text" name='email' id='email' onChange={SaveRegisteredEmail} placeholder='*******' required/>

          <p>*Telefone</p>
          <input type="text" name='telefone' id='telephone' onChange={SaveRegisteredTelephone} placeholder='55 11 12345-6789'/>

          <p>*CPF</p>
          <input type="text" name='cpf' id='cpf' onChange={SaveRegisteredCpf} placeholder='123.456.789-00'/>

        </div>
      
      </div>

      <div className={styles.cadastroDestino}>
        <p>cidades</p>
        <Select   
          isMulti
          name="colors"
          id='cityNameId'
          options={city}
          value={valueCity}
          onChange={setValueCity}
          className="basic-multi-select"
          classNamePrefix="select"
          
        />
        <p>país</p>
        <Select
          isMulti
          name="country"
          id='countryNameId'
          options={country}
          value={valueCountry}
          onChange={setValueCountry}
          className="basic-multi-select"
          classNamePrefix="select"      
        />
      </div>
      <button type="submit" onClick={Submit}>aaa</button>
      <div>
        <Registro
          name={allRegistryValue.name}
          email={allRegistryValue.email}
          cpf={allRegistryValue.cpf} 
          phone={allRegistryValue.telephone}
          city={cityStringValue}
          country={countryStringValue}
        />
      </div>
      
    </main>
  )
}