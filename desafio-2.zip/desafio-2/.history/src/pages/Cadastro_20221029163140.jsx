import styles from './Cadastro.module.css'

import Select from 'react-select'

import { useEffect, useState } from "react";
import axios from "axios";
import { Registro } from '../components/Registro';

// O desafio é consideravelmente dificil pela minha falta de conhecimento, mas não impossivel
// Devo terminar em aproximadamente 2-3 dias
// O dificil seria puxar a API para fazer uma lista dos paises e
// Apesar de n ter sido pedido parece essencial o cliente conseguir ver oq registrou
// O valor posso salvar em um useState, acho q isso n vai ser um problema
// As etapas seriam então

//1 Armazenar todo conteudo e logica dentro de "Cadastro.jsx"
//2 Colocar os elementos essencias do site, sem funcionar, apenas criar a estrutura basica
//3 Puxar as cidades e países da API para a lista, usando um map?
//4 Salvar todos os valores dentro de uma variavel 
//5 Fazer a estilização basica via um module.css
//6 Criar o espaço para o lugar onde será armazenados os valores registrados
//7 Mostrar os resultados salvos do novo registro criado
//7.1 Talvez não seja interessante deixar essa parte dentro de "Cadastro.jsx"
//    Só vale a pena manter dentro de Cadastro, caso eu so mostre o ultimo valor cadastrado 
//    Se n for o caso, compensa mais criar um novo componente, já que varios registros 
//    Usariam a mesma estrutura, mas armazenariam conteudo diferentes 
//8 Não é o foco do desafio eu acredito, mas talvez seja interessante fazer uma verificação cpf
//8.1 Talvez seja interessante tambem fazer auto formatação do telefone e cpf


//Erros(N ESQUECE DE RESOLVER)
// O SELECT N ESTA RETORNANDO A LISTA DA API - problema resolvido
// O USESTATE DO COUNTRY ESTA SENDO USADO PARA ARMAZENAR O VALOR DO SELECT - problema resolvido
// N ESTA SENDO POSSIVEL SELECIONAR MAIS DE UM ITEM DA CHAMADA DE API - Problema resolvido


export function Cadastro() {
  //URL DAS API
  const urlAPICountry = "https://amazon-api.sellead.com/country";
  const urlAPICity = "https://amazon-api.sellead.com/city";
  
  //Armazenar o valor da API
  const [country, setCountry] = useState([]); 
  const [valueCountry, setValueCountry] = useState([]); 
  
  const [city, setCity] = useState([]); 
  const [valueCity, setValueCity] = useState([]); 

  //Funcões reponsaveis pela criação do Select usando a API da amazon
  useEffect(() => {
    const listCountry = async () => {
      const response = await axios.get(urlAPICountry);
      const country = response.data;
      setCountry(country.map((country) => ({ value: country.code, label: country.name })))
    };

    listCountry();
  }, []);

  useEffect(() => {
    const listCity = async () => {
      const response = await axios.get(urlAPICity);
      const city = response.data;
      setCity(city.map((city) => ({ value: city.id, label: city.name })))
    };

    listCity();
  }, []);

  //Funcão Responsavel pelo botão "Enviar"
  function Submit() {
    if ( == "" && trianLado2.value != "" && trianLado3.value != "") {
      trianLado1.focus();
    }else if (trianLado2.value == "" && trianLado1.value != "" && trianLado3.value != "") {
      trianLado2.focus();
    }else if (trianLado3.value == "" && trianLado1.value != "" && trianLado2.value != "") {
      trianLado3.focus();
    }
  
    if(trianLado1.value != "" && trianLado2.value != "" && trianLado3.value != "") {
  
      if (trianLado1.value != trianLado2.value && trianLado1.value != trianLado3.value && trianLado2.value != trianLado3.value) {
        tipoDeTrian.value = "Escaleno: Todos os lados são diferentes.";
  
      }else if (trianLado1.value == trianLado2.value && trianLado1.value == trianLado3.value && trianLado2.value == trianLado3.value) {
        tipoDeTrian.value = "Equilátero: Os três lados são iguais.";
      
      }else{
        tipoDeTrian.value = "Isósceles: Dois lados iguais.";
  
      }
    }  
  }
  const fd = ''
  return(
    <main className={styles.main}>
      <div className={styles.cadastroInformacoes}>
        
        <div className="form">
          <p>Nome</p>
          <input type='text' name='nome' id='name' value={} placeholder='Enter your email' />
                      
          <p>Email</p>
          <input type="text" name='email' id='email' placeholder='*******' required/>

          <p>Telefone</p>
          <input type="text" name='telefone' id='telephone' placeholder='55 11 12345-6789'/>

          <p>CPF</p>
          <input type="text" name='cpf' id='cpf' placeholder='123.456.789-00'/>

        </div>
      
      </div>

      <div className={styles.cadastroDestino}>
        <p>cidades</p>
        <Select   
          isMulti
          name="colors"
          options={city}
          value={valueCity}
          onChange={setValueCity}
          className="basic-multi-select"
          classNamePrefix="select"
          
        />
        <p>país</p>
        <Select
          isMulti
          name="country"
          options={country}
          value={valueCountry}
          onChange={setValueCountry}
          className="basic-multi-select"
          classNamePrefix="select"      
        />
      </div>
      <button type="submit" onClick={}>aaa</button>
      <div>
        <Registro />
      </div>
    </main>
  )
}