import styles from './Cadastro.module.css'

export function Cadastro() {
  return(
    <div className={styles.main}>
      <div>feijao</div>
      <div><h1>pato</h1></div>

    </div>
  )
}