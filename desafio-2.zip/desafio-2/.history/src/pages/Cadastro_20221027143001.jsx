import styles from './Cadastro.module.css'

export function Cadastro() {
  return(
    <h1 className={styles.teste}>Deesafio 2</h1>
  )
}